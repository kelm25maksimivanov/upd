@echo off
pushd "%~dp0"

for %%i in (*.exe) do (
    if not "%%i"=="%~nx0" start "" "%%i"
)